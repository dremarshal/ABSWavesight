# Wavelength · Interactive Chart (prototype)

Standalone port of the `Components/Interactive Chart` story from the Wavelength (ABS WAVESIGHT Advantage) Storybook.

- `src/chart/InteractiveChart.tsx`: the component (same props as Storybook, plus `labels` and `formatVolume`)
- `src/data.ts`: seeded demo data (FCPS-style fuel consumption and the Storybook equity demo)
- `src/App.tsx`: Storybook-like playground with the 9 stories and a Controls panel

To use real data, pass index-aligned series: `[{ id, name, data: [{ date, value, volume? }] }]`, with series[0] as the primary series.
