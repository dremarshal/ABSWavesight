import * as React from "react";
import { ArrowUpRight, Newspaper, RotateCcw } from "lucide-react";
import {
  DrilldownStat,
  InteractiveChart,
  type ChartMode,
  type DrilldownContext,
  type DrilldownSide,
} from "./chart/InteractiveChart";
import { RANGE_CFG, fuelFormat, fuelSeries, nmFormat, stockSeries } from "./data";

type Dataset = "fuel" | "stock";

type Args = {
  dataset: Dataset;
  drilldown: DrilldownSide;
  drilldownTrigger: "pin" | "always";
  variant: "area" | "line";
  showVolume: boolean;
  showLastPrice: boolean;
  defaultMode: ChartMode;
  defaultRange: string;
  height: number;
  withOverlays: boolean;
  defaultPinned?: number[];
  defaultOverlays?: string[];
  customDrilldown?: boolean;
};

const BASE: Args = {
  dataset: "fuel",
  drilldown: "right",
  drilldownTrigger: "pin",
  variant: "area",
  showVolume: true,
  showLastPrice: true,
  defaultMode: "inspect",
  defaultRange: "1M",
  height: 340,
  withOverlays: true,
};

type Story = { id: string; name: string; desc: string; args: Partial<Args> };

const STORIES: Story[] = [
  { id: "playground", name: "Playground (drill-down right)", desc: "Hover to scrub, click to pin a point. Use the controls below to change every prop.", args: {} },
  { id: "bottom", name: "Drill-down · bottom", desc: "The drill-down panel opens under the plot, which suits narrow layouts.", args: { drilldown: "bottom", defaultMode: "compare", defaultRange: "6M", defaultPinned: [40, 100] } },
  { id: "top", name: "Drill-down · top", desc: "The drill-down panel opens above the plot.", args: { drilldown: "top", defaultMode: "compare", defaultRange: "6M", defaultPinned: [40, 100] } },
  { id: "compare", name: "Compare two points (A → B)", desc: "Compare mode: click two points to get the change, change %, span, high, low and average.", args: { defaultMode: "compare", defaultRange: "1M", defaultPinned: [4, 17] } },
  { id: "overlays", name: "Compare series (overlays, % change)", desc: "Switching on overlay series changes the y-axis to % change from the first point.", args: { defaultRange: "1Y", defaultOverlays: ["__1", "__2"], defaultMode: "compare", defaultPinned: [60, 190], drilldown: "right" } },
  { id: "always", name: "Always-open side panel (follows cursor)", desc: "The panel stays open and shows details for whatever the cursor is on.", args: { drilldownTrigger: "always", withOverlays: false, defaultRange: "6M" } },
  { id: "intraday", name: "Intraday (1D)", desc: "Line variant with intraday time labels.", args: { defaultRange: "1D", variant: "line" } },
  { id: "minimal", name: "Minimal (no volume, no panel)", desc: "A compact version with no bar pane and no drill-down.", args: { drilldown: "none", showVolume: false, withOverlays: false, height: 260, defaultRange: "1Y" } },
  { id: "custom", name: "Custom drill-down content", desc: "renderDrilldown replaces the panel body, for example with events or notes between two points.", args: { drilldown: "right", defaultMode: "compare", defaultRange: "6M", defaultPinned: [52, 96], customDrilldown: true } },
];

const DATASETS = {
  fuel: {
    label: "Fuel consumption (FCPS demo)",
    title: "Vessel A · Main engine fuel consumption",
    subtitle: "FCPS · tonnes per bar · demo data",
    icon: "ME",
    series: fuelSeries,
    formatValue: fuelFormat,
    formatVolume: nmFormat,
    labels: { value: "Fuel", volume: "Distance", chart: "fuel consumption chart" },
    notes: [
      "Heavy weather in the North Atlantic: speed reduced, consumption per mile up.",
      "Hull cleaning completed at anchorage; consumption back near prediction.",
    ],
  },
  stock: {
    label: "Equity (Storybook demo)",
    title: "NVDA · NVIDIA Corporation",
    subtitle: "Nasdaq · USD",
    icon: "NV",
    series: stockSeries,
    formatValue: undefined,
    formatVolume: undefined,
    labels: undefined,
    notes: [
      "Hedge funds trim tech exposure ahead of a possible correction.",
      "Chinese firms boost H20 chip orders on rising demand for AI models.",
    ],
  },
} as const;

function CustomPanel({ ctx, notes }: { ctx: DrilldownContext; notes: readonly string[] }) {
  const { stats: s, formatValue: fv, formatDate: fd, clear } = ctx;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <h3 className="t-small-m" style={{ margin: 0, display: "flex", alignItems: "center", gap: 6 }}>
          <Newspaper size={16} /> What moved the value
        </h3>
        <button type="button" className="btn ghost" onClick={clear}>Clear</button>
      </div>
      {s.a && s.b ? (
        <>
          <dl style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, margin: 0 }}>
            <DrilldownStat label="Move" value={`${(s.deltaPct ?? 0) >= 0 ? "+" : ""}${(s.deltaPct ?? 0).toFixed(2)}%`} tone={(s.deltaPct ?? 0) >= 0 ? "up" : "down"} />
            <DrilldownStat label="Range" value={`${fv(s.low ?? 0)} – ${fv(s.high ?? 0)}`} />
          </dl>
          <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
            {[s.a.date, s.b.date].map((d, i) => (
              <li key={String(d)} style={{ borderRadius: 6, background: "var(--grey-50)", padding: 10 }}>
                <p className="t-mini" style={{ margin: 0, color: "var(--grey-600)" }}>{fd(d)}</p>
                <p className="t-small" style={{ margin: 0 }}>{notes[i]}</p>
              </li>
            ))}
          </ul>
          <button type="button" className="btn" style={{ alignSelf: "flex-start" }}>
            Open full analysis <ArrowUpRight />
          </button>
        </>
      ) : (
        <p className="t-small" style={{ margin: 0, color: "var(--grey-700)" }}>Pin two points to see notes between them.</p>
      )}
    </div>
  );
}

function ChartStory({ args }: { args: Args }) {
  const ds = DATASETS[args.dataset];
  const [range, setRange] = React.useState(args.defaultRange);
  const all = React.useMemo(() => ds.series(range), [ds, range]);
  const series = args.withOverlays ? all : all.slice(0, 1);
  // Story overlay ids are positional ("__1" = second series) so presets work for both datasets.
  const overlays = (args.defaultOverlays ?? []).map((o) => (o.startsWith("__") ? all[+o.slice(2)]?.id : o)).filter(Boolean) as string[];

  return (
    <div style={{ maxWidth: 1080 }}>
      <InteractiveChart
        series={series}
        title={ds.title}
        subtitle={ds.subtitle}
        icon={<span className="t-mini-m">{ds.icon}</span>}
        range={range}
        onRangeChange={setRange}
        drilldown={args.drilldown}
        drilldownTrigger={args.drilldownTrigger}
        variant={args.variant}
        showVolume={args.showVolume}
        showLastPrice={args.showLastPrice}
        defaultMode={args.defaultMode}
        height={args.height}
        defaultPinned={args.defaultPinned}
        defaultOverlays={args.withOverlays ? overlays : []}
        formatValue={ds.formatValue}
        formatVolume={ds.formatVolume}
        labels={ds.labels}
        renderDrilldown={args.customDrilldown ? (ctx) => <CustomPanel ctx={ctx} notes={ds.notes} /> : undefined}
      />
    </div>
  );
}

function Radio<T extends string>({ name, value, options, onChange }: { name: string; value: T; options: readonly T[]; onChange: (v: T) => void }) {
  return (
    <div className="radio-row" role="radiogroup" aria-label={name}>
      {options.map((o) => (
        <label key={o}>
          <input type="radio" name={name} checked={value === o} onChange={() => onChange(o)} /> {o}
        </label>
      ))}
    </div>
  );
}

function Switch({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return <button type="button" role="switch" aria-label={label} aria-checked={checked} className="switch" onClick={() => onChange(!checked)} />;
}

export default function App() {
  const [storyId, setStoryId] = React.useState(STORIES[0].id);
  const story = STORIES.find((s) => s.id === storyId)!;
  const [args, setArgs] = React.useState<Args>({ ...BASE, ...story.args });
  const [rev, setRev] = React.useState(0);

  const selectStory = (s: Story) => {
    setStoryId(s.id);
    setArgs((a) => ({ ...BASE, dataset: a.dataset, ...s.args }));
    setRev((r) => r + 1);
  };
  const set = <K extends keyof Args>(k: K, v: Args[K]) => {
    setArgs((a) => ({ ...a, [k]: v }));
    setRev((r) => r + 1);
  };
  const reset = () => {
    setArgs((a) => ({ ...BASE, dataset: a.dataset, ...story.args }));
    setRev((r) => r + 1);
  };

  const rows: { name: string; desc: string; control: React.ReactNode }[] = [
    {
      name: "dataset",
      desc: "Demo data set (prototype only)",
      control: (
        <select className="sel" value={args.dataset} onChange={(e) => set("dataset", e.target.value as Dataset)}>
          {(Object.keys(DATASETS) as Dataset[]).map((k) => (
            <option key={k} value={k}>{DATASETS[k].label}</option>
          ))}
        </select>
      ),
    },
    { name: "drilldown", desc: "Where the drill-down panel opens", control: <Radio name="drilldown" value={args.drilldown} options={["right", "bottom", "top", "none"] as const} onChange={(v) => set("drilldown", v)} /> },
    { name: "drilldownTrigger", desc: '"pin": opens when a point is pinned. "always": stays open and follows the cursor', control: <Radio name="drilldownTrigger" value={args.drilldownTrigger} options={["pin", "always"] as const} onChange={(v) => set("drilldownTrigger", v)} /> },
    { name: "variant", desc: "Area or line", control: <Radio name="variant" value={args.variant} options={["area", "line"] as const} onChange={(v) => set("variant", v)} /> },
    { name: "defaultMode", desc: "Inspect pins one point; Compare pins two", control: <Radio name="defaultMode" value={args.defaultMode} options={["inspect", "compare"] as const} onChange={(v) => set("defaultMode", v)} /> },
    {
      name: "defaultRange",
      desc: "Initial time range",
      control: (
        <select className="sel" value={args.defaultRange} onChange={(e) => set("defaultRange", e.target.value)}>
          {Object.keys(RANGE_CFG).map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
      ),
    },
    {
      name: "height",
      desc: "Plot height in px",
      control: (
        <label style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13 }}>
          <input type="range" min={240} max={520} step={20} value={args.height} onChange={(e) => set("height", +e.target.value)} aria-label="height" />
          <span className="tnum">{args.height}</span>
        </label>
      ),
    },
    { name: "showVolume", desc: "Bar pane under the plot", control: <Switch label="showVolume" checked={args.showVolume} onChange={(v) => set("showVolume", v)} /> },
    { name: "showLastPrice", desc: "Dotted line and badge at the latest value", control: <Switch label="showLastPrice" checked={args.showLastPrice} onChange={(v) => set("showLastPrice", v)} /> },
    { name: "withOverlays", desc: "Show Compare chips for extra series", control: <Switch label="withOverlays" checked={args.withOverlays} onChange={(v) => set("withOverlays", v)} /> },
  ];

  return (
    <div className="shell">
      <nav className="sidebar" aria-label="Stories">
        <div className="brand">
          <span className="brand-mark">W</span>
          <div>
            <div className="t-small-m">Wavelength</div>
            <div className="t-mini" style={{ color: "var(--grey-500)" }}>Advantage Design System</div>
          </div>
        </div>
        <div className="nav-label">Components / Interactive Chart</div>
        {STORIES.map((s) => (
          <button key={s.id} type="button" className="nav-item" aria-current={s.id === storyId} onClick={() => selectStory(s)}>
            {s.name}
          </button>
        ))}
      </nav>

      <div className="main">
        <header className="topbar">
          <div>
            <div className="t-small-m">Interactive Chart</div>
            <div className="t-mini" style={{ color: "var(--grey-500)" }}>{story.name}</div>
          </div>
          <select
            className="sel"
            aria-label="Story"
            value={storyId}
            onChange={(e) => selectStory(STORIES.find((s) => s.id === e.target.value)!)}
            style={{ maxWidth: 260 }}
          >
            {STORIES.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </header>

        <main className="canvas">
          <p className="t-small story-desc">{story.desc} Keyboard: ←/→ move (Shift ×10), Home/End, Enter pins, Esc clears.</p>
          <ChartStory key={rev} args={args} />
        </main>

        <section className="controls" aria-label="Controls">
          <div className="controls-head">
            <span className="t-small-m">Controls</span>
            <button type="button" className="btn ghost" onClick={reset}>
              <RotateCcw size={14} /> Reset story
            </button>
          </div>
          <table className="ctl-table">
            <tbody>
              {rows.map((r) => (
                <tr key={r.name}>
                  <th scope="row">
                    <div className="ctl-name">{r.name}</div>
                    <div className="ctl-desc">{r.desc}</div>
                  </th>
                  <td>{r.control}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
}
