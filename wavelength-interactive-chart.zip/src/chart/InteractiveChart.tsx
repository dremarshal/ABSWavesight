import * as React from "react";
import { ArrowDownRight, ArrowUpRight, Crosshair, MousePointerClick, X } from "lucide-react";
import {
  RANGE_LABEL,
  chartColor as color,
  compact,
  defaultFormatDate,
  humanSpan,
  niceTicks,
  pct,
  signedValue,
  tone,
  usd,
  type DateCtx,
} from "./format";

export type ChartPoint = { date: Date; value: number; volume?: number };
export type ChartSeries = { id: string; name: string; data: ChartPoint[] };
export type ChartMode = "inspect" | "compare";
export type DrilldownSide = "right" | "bottom" | "top" | "none";

export type SelectionStats = {
  indices: number[];
  a?: ChartPoint & { index: number };
  b?: ChartPoint & { index: number };
  vsStartPct?: number;
  vsPrevPct?: number;
  deltaValue?: number;
  deltaPct?: number;
  bars?: number;
  spanMs?: number;
  high?: number;
  low?: number;
  avgVolume?: number;
};

export type DrilldownContext = {
  primary: ChartSeries;
  visible: ChartSeries[];
  stats: SelectionStats;
  mode: ChartMode;
  range: string;
  side: Exclude<DrilldownSide, "none">;
  formatValue: (v: number) => string;
  formatDate: (d: Date) => string;
  formatVolume: (v: number) => string;
  clear: () => void;
  labels: Labels;
};

export type Labels = {
  /** Name of the main value, e.g. "Close" or "Fuel". */
  value: string;
  /** Name of the bar pane value, e.g. "Volume" or "Distance". */
  volume: string;
  /** Used in the screen-reader description, e.g. "price chart". */
  chart: string;
};

export type InteractiveChartProps = {
  series: ChartSeries[];
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  icon?: React.ReactNode;
  ranges?: string[];
  range?: string;
  defaultRange?: string;
  onRangeChange?: (range: string) => void;
  mode?: ChartMode;
  defaultMode?: ChartMode;
  onModeChange?: (mode: ChartMode) => void;
  pinned?: number[];
  defaultPinned?: number[];
  onPinnedChange?: (indices: number[]) => void;
  overlays?: string[];
  defaultOverlays?: string[];
  onOverlaysChange?: (ids: string[]) => void;
  drilldown?: DrilldownSide;
  drilldownTrigger?: "pin" | "always";
  renderDrilldown?: (ctx: DrilldownContext) => React.ReactNode;
  variant?: "area" | "line";
  showVolume?: boolean;
  showLastPrice?: boolean;
  height?: number;
  formatValue?: (v: number) => string;
  formatVolume?: (v: number) => string;
  formatDate?: (d: Date, kind: "axis" | "full", ctx: DateCtx) => string;
  labels?: Partial<Labels>;
  className?: string;
};

const DEFAULT_RANGES = ["1D", "5D", "1M", "6M", "1Y", "5Y", "All"];
const PAD = { l: 12, r: 64, t: 24, b: 28 };

function useWidth() {
  const ref = React.useRef<HTMLDivElement>(null);
  const [w, setW] = React.useState(0);
  React.useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setW(Math.round(e.contentRect.width)));
    ro.observe(el);
    setW(Math.round(el.getBoundingClientRect().width));
    return () => ro.disconnect();
  }, []);
  return [ref, w] as const;
}

function useIsMobile() {
  const [m, setM] = React.useState(false);
  React.useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const on = () => setM(mq.matches);
    on();
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return m;
}

function useControllable<T>(value: T | undefined, initial: T, onChange?: (v: T) => void) {
  const [inner, setInner] = React.useState(initial);
  const controlled = value !== undefined;
  const set = React.useCallback(
    (v: T) => {
      if (!controlled) setInner(v);
      onChange?.(v);
    },
    [controlled, onChange],
  );
  return [controlled ? (value as T) : inner, set] as const;
}

export function InteractiveChart({
  series,
  title,
  subtitle,
  icon,
  ranges = DEFAULT_RANGES,
  range: rangeProp,
  defaultRange,
  onRangeChange,
  mode: modeProp,
  defaultMode = "inspect",
  onModeChange,
  pinned: pinnedProp,
  defaultPinned = [],
  onPinnedChange,
  overlays: overlaysProp,
  defaultOverlays = [],
  onOverlaysChange,
  drilldown = "right",
  drilldownTrigger = "pin",
  renderDrilldown,
  variant = "area",
  showVolume = true,
  showLastPrice = true,
  height = 340,
  formatValue = usd,
  formatVolume = compact,
  formatDate,
  labels: labelsProp,
  className,
}: InteractiveChartProps) {
  const labels: Labels = { value: "Close", volume: "Volume", chart: "price chart", ...labelsProp };
  const [range, setRange] = useControllable(rangeProp, defaultRange ?? ranges[2] ?? ranges[0], onRangeChange);
  const [mode, setMode] = useControllable<ChartMode>(modeProp, defaultMode, onModeChange);
  const [pins, setPins] = useControllable<number[]>(pinnedProp, defaultPinned, onPinnedChange);
  const [overlayIds, setOverlayIds] = useControllable<string[]>(overlaysProp, defaultOverlays, onOverlaysChange);
  const [hover, setHover] = React.useState<number | null>(null);
  const [live, setLive] = React.useState("");
  const gradId = `ic-grad-${React.useId().replace(/:/g, "")}`;
  const isMobile = useIsMobile();
  const side0 = drilldown === "right" && isMobile ? "bottom" : drilldown;

  const primary = series[0];
  const data = primary.data;
  const n = data.length;
  const others = series.slice(1);
  const visible = [primary, ...others.filter((s) => overlayIds.includes(s.id))];
  const isPct = visible.length > 1;
  const spanMs = n > 1 ? +data[n - 1].date - +data[0].date : 0;
  const dctx = { spanMs, stepMs: n > 1 ? spanMs / (n - 1) : 0 };
  const fmtFull = (d: Date) => (formatDate ?? defaultFormatDate)(d, "full", dctx);
  const fmtAxis = (d: Date) => (formatDate ?? defaultFormatDate)(d, "axis", dctx);

  const [plotRef, W] = useWidth();
  const volH = showVolume && data.some((p) => p.volume != null) ? 48 : 0;
  const gap = volH ? 10 : 0;
  const plotH = height - PAD.t - PAD.b - volH - gap;
  const plotW = Math.max(W - PAD.l - PAD.r, 1);
  const x = (i: number) => PAD.l + (n > 1 ? (i / (n - 1)) * plotW : plotW / 2);

  const values = React.useMemo(
    () =>
      visible.map((s) => {
        const base = s.data[0]?.value || 1;
        return isPct ? s.data.map((p) => (p.value / base - 1) * 100) : s.data.map((p) => p.value);
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [series, overlayIds],
  );
  const flat = values.flat();
  const lo = Math.min(...flat);
  const hi = Math.max(...flat);
  const padV = (hi - lo || 1) * 0.08;
  const yMin = lo - padV;
  const yMax = hi + padV;
  const y = (v: number) => PAD.t + plotH * (1 - (v - yMin) / (yMax - yMin));
  const ticks = niceTicks(yMin, yMax, 5);
  const fmtTick = (v: number) => (isPct ? pct(v, Math.abs(v) < 10 ? 1 : 0) : formatValue(v));
  const maxVol = Math.max(...data.map((p) => p.volume ?? 0), 1);

  const validPins = pins.filter((i) => i >= 0 && i < n).slice(0, 2);
  const lastPins = React.useRef<number[]>([]);
  if (validPins.length) lastPins.current = validPins;
  const panelPins = validPins.length ? validPins : lastPins.current.filter((i) => i < n);
  const cursor = hover === null ? null : Math.min(hover, n - 1);

  const togglePin = (i: number) => {
    let next: number[];
    if (mode === "inspect") next = validPins.length === 1 && validPins[0] === i ? [] : [i];
    else if (validPins.length >= 2) next = [i];
    else next = validPins.includes(i) ? validPins.filter((p) => p !== i) : [...validPins, i];
    setPins(next);
    const p = data[i];
    setLive(
      next.length === 0
        ? "Selection cleared"
        : `${next.length === 2 ? "Point B" : "Point A"} pinned: ${fmtFull(p.date)}, ${formatValue(p.value)}`,
    );
  };
  const clear = () => {
    setPins([]);
    setLive("Selection cleared");
  };
  const changeRange = (r: string) => {
    if (r && r !== range) {
      setPins([]);
      setHover(null);
      setRange(r);
    }
  };
  const changeMode = (m: ChartMode) => {
    if (m && m !== mode) {
      setMode(m);
      if (m === "inspect" && validPins.length > 1) setPins(validPins.slice(0, 1));
    }
  };
  const indexAt = (e: React.PointerEvent | React.MouseEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const i = Math.round(((e.clientX - r.left - PAD.l) / plotW) * (n - 1));
    return Math.max(0, Math.min(n - 1, i));
  };
  const onKey = (e: React.KeyboardEvent) => {
    const cur = cursor ?? n - 1;
    const step = e.shiftKey ? 10 : 1;
    const go = (t: number) => {
      const i = Math.max(0, Math.min(n - 1, t));
      setHover(i);
      setLive(`${fmtFull(data[i].date)}, ${formatValue(data[i].value)}`);
      e.preventDefault();
    };
    if (e.key === "ArrowRight") go(cur + step);
    else if (e.key === "ArrowLeft") go(cur - step);
    else if (e.key === "Home") go(0);
    else if (e.key === "End") go(n - 1);
    else if (e.key === "Enter" || e.key === " ") {
      togglePin(cur);
      e.preventDefault();
    } else if (e.key === "Escape") validPins.length ? clear() : setHover(null);
  };

  const stats = (idx: number[]): SelectionStats => {
    const s: SelectionStats = { indices: idx };
    if (idx.length === 1) {
      const i = idx[0];
      s.a = { ...data[i], index: i };
      s.vsStartPct = (data[i].value / data[0].value - 1) * 100;
      s.vsPrevPct = i > 0 ? (data[i].value / data[i - 1].value - 1) * 100 : 0;
    } else if (idx.length === 2) {
      const [ia, ib] = idx;
      const [from, to] = ia < ib ? [ia, ib] : [ib, ia];
      const slice = data.slice(from, to + 1);
      s.a = { ...data[ia], index: ia };
      s.b = { ...data[ib], index: ib };
      s.deltaValue = data[ib].value - data[ia].value;
      s.deltaPct = (data[ib].value / data[ia].value - 1) * 100;
      s.bars = to - from;
      s.spanMs = Math.abs(+data[ib].date - +data[ia].date);
      s.high = Math.max(...slice.map((p) => p.value));
      s.low = Math.min(...slice.map((p) => p.value));
      const vols = slice.filter((p) => p.volume != null).map((p) => p.volume as number);
      s.avgVolume = vols.length ? vols.reduce((a, b) => a + b, 0) / vols.length : undefined;
    }
    return s;
  };

  const preview = mode === "compare" && validPins.length === 1 && cursor !== null && cursor !== validPins[0];
  const band = validPins.length === 2 ? validPins : preview ? [validPins[0], cursor as number] : [];
  const bandStats = band.length === 2 ? stats(band) : null;

  const headVal = data[cursor ?? n - 1]?.value ?? 0;
  const headDelta = headVal - data[0].value;
  const headPct = (headVal / data[0].value - 1) * 100;
  const up = headDelta >= 0;

  const side = side0 === "none" ? null : side0;
  const panelOpen = side !== null && (drilldownTrigger === "always" || validPins.length > 0);
  const clampX = (v: number, w: number) => Math.max(PAD.l, Math.min(W - PAD.r - w, v));
  const ctx: DrilldownContext | null = side
    ? {
        primary,
        visible,
        stats: stats(drilldownTrigger === "always" && !panelPins.length && cursor !== null ? [cursor] : panelPins),
        mode,
        range,
        side,
        formatValue,
        formatDate: fmtFull,
        formatVolume,
        clear,
        labels,
      }
    : null;

  const xTickCount = W < 520 ? 3 : W < 760 ? 4 : 6;
  const xTicks = n > 1 ? Array.from({ length: xTickCount }, (_, k) => Math.round(((n - 1) * k) / (xTickCount - 1))) : [0];
  const seriesIndex = (id: string) => series.findIndex((s) => s.id === id);

  return (
    <div data-slot="interactive-chart" className={className} style={{ width: "100%", borderRadius: 8, background: "var(--grey-50)", padding: 8 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 12, borderRadius: 6, background: "#fff", padding: 16 }}>
        {/* Header */}
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {icon && (
              <span
                style={{
                  display: "flex", width: 40, height: 40, flexShrink: 0, alignItems: "center", justifyContent: "center",
                  overflow: "hidden", borderRadius: 8, background: "var(--grey-100)",
                }}
              >
                {icon}
              </span>
            )}
            <div>
              {title && <p className="t-small-m" style={{ margin: 0 }}>{title}</p>}
              {subtitle && <p className="t-mini" style={{ margin: 0, color: "var(--grey-600)" }}>{subtitle}</p>}
            </div>
          </div>
          <div style={{ textAlign: "right" }} aria-hidden="true">
            <p className="t-h4 tnum" style={{ margin: 0 }}>{formatValue(headVal)}</p>
            <p
              className="t-small-m tnum"
              style={{ margin: 0, display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 4, color: up ? "var(--green-800)" : "var(--red-700)" }}
            >
              {up ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
              {signedValue(headDelta, formatValue)} ({pct(headPct)})
              <span style={{ fontWeight: 400, color: "var(--grey-600)" }}>
                · {cursor === null ? RANGE_LABEL[range] ?? range : fmtFull(data[cursor].date)}
              </span>
            </p>
          </div>
        </div>

        {/* Toolbar */}
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", columnGap: 16, rowGap: 8 }}>
          <div className="tg ghost" role="radiogroup" aria-label="Time range">
            {ranges.map((r) => (
              <button
                key={r}
                type="button"
                role="radio"
                aria-checked={r === range}
                data-state={r === range ? "on" : "off"}
                className="tg-item"
                onClick={() => changeRange(r)}
              >
                {r}
              </button>
            ))}
          </div>
          {others.length > 0 && (
            <div role="group" aria-label="Compare with" style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8 }}>
              <span className="t-mini-m" style={{ color: "var(--grey-600)" }}>Compare</span>
              {others.map((s, k) => {
                const on = overlayIds.includes(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    className="chip"
                    aria-pressed={on}
                    onClick={() => setOverlayIds(on ? overlayIds.filter((id) => id !== s.id) : [...overlayIds, s.id])}
                  >
                    <span className="dot" style={{ background: color(k + 1) }} />
                    {s.name}
                  </button>
                );
              })}
            </div>
          )}
          <div className="tg outlined" role="radiogroup" aria-label="Pointer mode" style={{ marginLeft: "auto" }}>
            <button
              type="button"
              role="radio"
              aria-checked={mode === "inspect"}
              data-state={mode === "inspect" ? "on" : "off"}
              className="tg-item"
              aria-label="Inspect: click pins one point"
              onClick={() => changeMode("inspect")}
            >
              <MousePointerClick /> Inspect
            </button>
            <button
              type="button"
              role="radio"
              aria-checked={mode === "compare"}
              data-state={mode === "compare" ? "on" : "off"}
              className="tg-item"
              aria-label="Compare points: click two points"
              onClick={() => changeMode("compare")}
            >
              <Crosshair /> Compare points
            </button>
          </div>
        </div>

        {/* Plot + drill-down */}
        <div
          style={{
            display: "flex",
            minWidth: 0,
            flexDirection: side === "right" ? "row" : side === "top" ? "column-reverse" : "column",
          }}
        >
          <div ref={plotRef} style={{ position: "relative", minWidth: 0, height, flex: side === "right" ? "1 1 0%" : "none", width: side === "right" ? undefined : "100%" }}>
            {W > 0 && (
              <>
                <svg width={W} height={height} style={{ position: "absolute", inset: 0, overflow: "visible" }} aria-hidden="true">
                  <defs>
                    <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor={color(0)} stopOpacity={0.22} />
                      <stop offset="100%" stopColor={color(0)} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  {ticks.map((t) => (
                    <g key={t}>
                      <line x1={PAD.l} x2={W - PAD.r} y1={y(t)} y2={y(t)} stroke="var(--grey-200)" strokeWidth={1} />
                      <text x={W - PAD.r + 8} y={y(t) + 4} fill="var(--grey-600)" style={{ fontSize: 11 }}>
                        {fmtTick(t)}
                      </text>
                    </g>
                  ))}
                  {isPct && (
                    <line x1={PAD.l} x2={W - PAD.r} y1={y(0)} y2={y(0)} stroke="var(--grey-400)" strokeWidth={1} strokeDasharray="3 3" />
                  )}
                  {xTicks.map((i, k) => (
                    <text
                      key={k}
                      x={x(i)}
                      y={height - 8}
                      textAnchor={k === 0 ? "start" : k === xTicks.length - 1 ? "end" : "middle"}
                      fill="var(--grey-600)"
                      style={{ fontSize: 11 }}
                    >
                      {fmtAxis(data[i].date)}
                    </text>
                  ))}
                  {bandStats && (
                    <rect
                      x={Math.min(x(band[0]), x(band[1]))}
                      width={Math.abs(x(band[1]) - x(band[0]))}
                      y={PAD.t}
                      height={plotH + gap + volH}
                      fill={color(0)}
                      fillOpacity={preview ? 0.05 : 0.09}
                    />
                  )}
                  {volH > 0 &&
                    data.map((p, i) => {
                      const bw = Math.max(1, (plotW / n) * 0.7);
                      const bh = Math.max(1, ((p.volume ?? 0) / maxVol) * volH);
                      const hot = cursor === i || validPins.includes(i);
                      return (
                        <rect
                          key={i}
                          x={x(i) - bw / 2}
                          y={PAD.t + plotH + gap + (volH - bh)}
                          width={bw}
                          height={bh}
                          fill={color(0)}
                          fillOpacity={hot ? 0.9 : 0.25}
                        />
                      );
                    })}
                  {visible.map((s, k) => {
                    const d = values[k].map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
                    return (
                      <g key={s.id}>
                        {variant === "area" && !isPct && (
                          <path d={`${d} L${x(n - 1)},${PAD.t + plotH} L${x(0)},${PAD.t + plotH} Z`} fill={`url(#${gradId})`} />
                        )}
                        <path d={d} fill="none" stroke={color(seriesIndex(s.id))} strokeWidth={1.75} strokeLinejoin="round" strokeLinecap="round" />
                      </g>
                    );
                  })}
                  {showLastPrice && (
                    <line
                      x1={PAD.l}
                      x2={W - PAD.r}
                      y1={y(values[0][n - 1])}
                      y2={y(values[0][n - 1])}
                      stroke={color(0)}
                      strokeWidth={1}
                      strokeDasharray="2 3"
                      strokeOpacity={0.7}
                    />
                  )}
                  {validPins.map((i, k) => (
                    <g key={i}>
                      <line x1={x(i)} x2={x(i)} y1={PAD.t - 4} y2={PAD.t + plotH + gap + volH} stroke="var(--grey-900)" strokeWidth={1} strokeDasharray="4 3" />
                      {visible.map((s, j) => (
                        <circle key={s.id} cx={x(i)} cy={y(values[j][i])} r={4.5} fill="white" stroke={color(seriesIndex(s.id))} strokeWidth={2} />
                      ))}
                      <title>{`Point ${k ? "B" : "A"}`}</title>
                    </g>
                  ))}
                  {cursor !== null && (
                    <g>
                      <line x1={x(cursor)} x2={x(cursor)} y1={PAD.t} y2={PAD.t + plotH + gap + volH} stroke="var(--grey-500)" strokeWidth={1} />
                      <line x1={PAD.l} x2={W - PAD.r} y1={y(values[0][cursor])} y2={y(values[0][cursor])} stroke="var(--grey-400)" strokeWidth={1} strokeDasharray="3 3" />
                      {visible.map((s, j) => (
                        <circle key={s.id} cx={x(cursor)} cy={y(values[j][cursor])} r={4} fill={color(seriesIndex(s.id))} stroke="white" strokeWidth={2} />
                      ))}
                    </g>
                  )}
                </svg>

                {/* HTML overlay: badges, flags, tooltip */}
                <div className="t-mini-m tnum" style={{ pointerEvents: "none", position: "absolute", inset: 0 }}>
                  {showLastPrice && cursor === null && (
                    <span className="badge" style={{ background: "var(--primary)", left: W - PAD.r + 2, top: y(values[0][n - 1]), transform: "translateY(-50%)" }}>
                      {fmtTick(values[0][n - 1])}
                    </span>
                  )}
                  {validPins.map((i, k) => (
                    <span
                      key={i}
                      style={{
                        position: "absolute", left: x(i), top: 0, transform: "translateX(-50%)",
                        display: "flex", width: 18, height: 18, alignItems: "center", justifyContent: "center",
                        borderRadius: 4, background: "var(--grey-900)", color: "#fff",
                      }}
                    >
                      {k === 0 ? "A" : "B"}
                    </span>
                  ))}
                  {bandStats && bandStats.deltaValue !== undefined && (
                    <span
                      style={{
                        position: "absolute",
                        left: clampX((x(band[0]) + x(band[1])) / 2 - 72, 144),
                        top: PAD.t + 6,
                        width: 144,
                        display: "flex", alignItems: "center", justifyContent: "center", gap: 4, whiteSpace: "nowrap",
                        borderRadius: 999, padding: "2px 8px",
                        border: `1px solid ${bandStats.deltaValue >= 0 ? "var(--green-200)" : "var(--red-200)"}`,
                        background: bandStats.deltaValue >= 0 ? "var(--green-50)" : "var(--red-50)",
                        color: bandStats.deltaValue >= 0 ? "var(--green-800)" : "var(--red-700)",
                        boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
                        opacity: preview ? 0.8 : 1,
                      }}
                    >
                      {signedValue(bandStats.deltaValue, formatValue)} · {pct(bandStats.deltaPct ?? 0)}
                    </span>
                  )}
                  {cursor !== null && (
                    <>
                      <span className="badge" style={{ background: "var(--grey-900)", left: W - PAD.r + 2, top: y(values[0][cursor]), transform: "translateY(-50%)" }}>
                        {fmtTick(values[0][cursor])}
                      </span>
                      <span className="badge" style={{ background: "var(--grey-900)", left: Math.max(0, Math.min(W - PAD.r - 90, x(cursor) - 45)), top: height - PAD.b + 2 }}>
                        {fmtFull(data[cursor].date)}
                      </span>
                      <div
                        style={{
                          position: "absolute",
                          width: 176,
                          left: x(cursor) + 14 + 176 > W - PAD.r ? x(cursor) - 14 - 176 : x(cursor) + 14,
                          top: PAD.t + 30,
                          borderRadius: 6, background: "var(--grey-900)", color: "#fff", padding: 8,
                          boxShadow: "0 10px 15px -3px rgba(0,0,0,.1), 0 4px 6px -4px rgba(0,0,0,.1)",
                        }}
                      >
                        <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,.2)", paddingBottom: 4 }}>
                          <span>{fmtAxis(data[cursor].date)}</span>
                          <span style={{ color: "var(--grey-400)" }}>{isPct ? "Change" : labels.value}</span>
                        </div>
                        <ul style={{ listStyle: "none", margin: 0, padding: "6px 0 0", display: "flex", flexDirection: "column", gap: 4 }}>
                          {visible.map((s, j) => (
                            <li key={s.id} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <span className="dot" style={{ background: color(seriesIndex(s.id)) }} />
                              <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontWeight: 400, color: "var(--grey-200)" }}>{s.name}</span>
                              <span>{isPct ? pct(values[j][cursor]) : formatValue(s.data[cursor].value)}</span>
                            </li>
                          ))}
                          {data[cursor].volume != null && (
                            <li style={{ display: "flex", alignItems: "center", gap: 6, borderTop: "1px solid rgba(255,255,255,.2)", paddingTop: 4, fontWeight: 400, color: "var(--grey-300)" }}>
                              <span style={{ flex: 1 }}>{labels.volume}</span>
                              <span>{formatVolume(data[cursor].volume as number)}</span>
                            </li>
                          )}
                        </ul>
                      </div>
                    </>
                  )}
                </div>

                <div
                  role="application"
                  aria-roledescription="interactive chart"
                  aria-label={`${typeof title === "string" ? title + " " : ""}${labels.chart}, ${RANGE_LABEL[range] ?? range}. Use left and right arrow keys to move the cursor, Enter to pin a point, Escape to clear.`}
                  tabIndex={0}
                  className="plot-hit"
                  onPointerMove={(e) => setHover(indexAt(e))}
                  onPointerDown={(e) => setHover(indexAt(e))}
                  onPointerLeave={(e) => {
                    if (document.activeElement !== e.currentTarget) setHover(null);
                  }}
                  onClick={(e) => togglePin(indexAt(e))}
                  onFocus={() => hover === null && setHover(n - 1)}
                  onBlur={() => setHover(null)}
                  onKeyDown={onKey}
                />
                <p className="sr-only" aria-live="polite" role="status">{live}</p>
              </>
            )}
          </div>

          {side && ctx && (
            <div
              className={side === "right" ? "drill-right" : "drill-v"}
              style={side === "right" ? { width: panelOpen ? 288 : 0 } : { gridTemplateRows: panelOpen ? "1fr" : "0fr" }}
              {...((!panelOpen ? { inert: "" } : {}) as Record<string, string>)}
            >
              <div style={side !== "right" ? { minHeight: 0, overflow: "hidden" } : undefined}>
                <aside
                  data-slot="chart-drilldown"
                  data-side={side}
                  aria-label="Selection details"
                  style={{
                    background: "#fff",
                    ...(side === "right" && { marginLeft: 16, width: 272, borderLeft: "1px solid var(--grey-200)", paddingLeft: 16 }),
                    ...(side === "bottom" && { marginTop: 12, borderTop: "1px solid var(--grey-200)", paddingTop: 12 }),
                    ...(side === "top" && { marginBottom: 12, borderBottom: "1px solid var(--grey-200)", paddingBottom: 12 }),
                  }}
                >
                  {renderDrilldown ? renderDrilldown(ctx) : <SelectionPanel {...ctx} showClose={drilldownTrigger === "pin"} />}
                </aside>
              </div>
            </div>
          )}
        </div>
        {!side && <p className="sr-only">Drill-down disabled</p>}
      </div>
    </div>
  );
}

export function DrilldownStat({
  label,
  value,
  tone: t,
  span,
}: {
  label: React.ReactNode;
  value: React.ReactNode;
  tone?: "up" | "down";
  span?: boolean;
}) {
  return (
    <div style={{ minWidth: 0, gridColumn: span ? "1 / -1" : undefined }}>
      <dt className="t-mini" style={{ color: "var(--grey-600)" }}>{label}</dt>
      <dd
        className="t-small-m tnum"
        style={{
          margin: 0,
          overflowWrap: "anywhere",
          color: t === "up" ? "var(--green-800)" : t === "down" ? "var(--red-700)" : "var(--grey-900)",
        }}
      >
        {value}
      </dd>
    </div>
  );
}

function SelectionPanel({
  stats: s,
  visible,
  primary,
  side,
  formatValue: fv,
  formatDate: fd,
  formatVolume: fvol,
  mode,
  clear,
  labels,
  showClose = true,
}: DrilldownContext & { showClose?: boolean }) {
  const grid: React.CSSProperties =
    side === "right"
      ? { display: "grid", gridTemplateColumns: "1fr 1fr", columnGap: 16, rowGap: 12, margin: 0 }
      : { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(132px, 1fr))", columnGap: 24, rowGap: 12, margin: 0 };
  const { a, b } = s;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <h3 className="t-small-m" style={{ margin: 0 }}>{b ? "Comparing two points" : a ? "Selected point" : "Selection"}</h3>
        {showClose && (
          <button type="button" className="icon-btn" onClick={clear} aria-label="Close drill-down and clear selection">
            <X size={16} />
          </button>
        )}
      </div>
      {!a && (
        <p className="t-small" style={{ margin: 0, display: "flex", alignItems: "flex-start", gap: 8, color: "var(--grey-700)" }}>
          <MousePointerClick size={16} style={{ marginTop: 2, flexShrink: 0 }} />
          {mode === "compare" ? "Click two points on the chart to compare them." : "Click the chart to pin a point and see its details."}
        </p>
      )}
      {a && !b && (
        <dl style={grid}>
          <DrilldownStat label="Date" value={fd(a.date)} span />
          <DrilldownStat label={labels.value} value={fv(a.value)} />
          {a.volume != null && <DrilldownStat label={labels.volume} value={fvol(a.volume)} />}
          <DrilldownStat label="Since range start" value={pct(s.vsStartPct ?? 0)} tone={tone(s.vsStartPct)} />
          <DrilldownStat label="Vs previous bar" value={pct(s.vsPrevPct ?? 0)} tone={tone(s.vsPrevPct)} />
        </dl>
      )}
      {a && b && (
        <>
          <dl style={grid}>
            <DrilldownStat label={<>A · {fd(a.date)}</>} value={fv(a.value)} />
            <DrilldownStat label={<>B · {fd(b.date)}</>} value={fv(b.value)} />
            <DrilldownStat label="Change" value={signedValue(s.deltaValue ?? 0, fv)} tone={tone(s.deltaValue)} />
            <DrilldownStat label="Change %" value={pct(s.deltaPct ?? 0)} tone={tone(s.deltaPct)} />
            <DrilldownStat label="Span" value={`${s.bars} bars · ${humanSpan(s.spanMs ?? 0)}`} />
            <DrilldownStat label="High" value={fv(s.high ?? 0)} />
            <DrilldownStat label="Low" value={fv(s.low ?? 0)} />
            {s.avgVolume != null && <DrilldownStat label={`Avg ${labels.volume.toLowerCase()}`} value={fvol(s.avgVolume)} />}
          </dl>
          {visible.length > 1 && (
            <table className="t-mini" style={{ width: "100%", borderCollapse: "collapse" }}>
              <caption className="sr-only">Change between A and B per series</caption>
              <thead>
                <tr style={{ textAlign: "left", color: "var(--grey-600)" }}>
                  <th scope="col" style={{ paddingBottom: 4, fontWeight: 400 }}>Series</th>
                  <th scope="col" style={{ paddingBottom: 4, fontWeight: 400, textAlign: "right" }}>A → B</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((ser) => {
                  const c = (ser.data[b.index].value / ser.data[a.index].value - 1) * 100;
                  return (
                    <tr key={ser.id} style={{ borderTop: "1px solid var(--grey-200)" }}>
                      <th scope="row" style={{ padding: "4px 0", textAlign: "left", fontWeight: 500 }}>
                        {ser.id === primary.id ? `${ser.name} (primary)` : ser.name}
                      </th>
                      <td className="tnum" style={{ padding: "4px 0", textAlign: "right", fontWeight: 500, color: c >= 0 ? "var(--green-800)" : "var(--red-700)" }}>
                        {pct(c)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </>
      )}
    </div>
  );
}
