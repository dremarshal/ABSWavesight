export const DAY = 864e5;

export const RANGE_LABEL: Record<string, string> = {
  "1D": "Today",
  "5D": "Past 5 days",
  "1M": "Past month",
  "6M": "Past 6 months",
  YTD: "Year to date",
  "1Y": "Past year",
  "5Y": "Past 5 years",
  All: "All time",
};

export const usd = (v: number) =>
  v.toLocaleString("en-US", { style: "currency", currency: "USD" });

const sign = (v: number) => (v > 0 ? "+" : v < 0 ? "-" : "");

export const signedValue = (v: number, fmt: (n: number) => string) =>
  `${sign(v)}${fmt(Math.abs(v))}`;

export const pct = (v: number, digits = 2) => `${sign(v)}${Math.abs(v).toFixed(digits)}%`;

export const compact = (v: number) =>
  Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(v);

export type DateCtx = { spanMs: number; stepMs: number };

export function defaultFormatDate(d: Date, kind: "axis" | "full", ctx: DateCtx) {
  const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  if (kind === "axis") {
    if (ctx.spanMs < 2 * DAY) return time;
    if (ctx.spanMs > 912.5 * DAY) return String(d.getFullYear());
    if (ctx.spanMs > 200 * DAY) return d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  }
  const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  return ctx.stepMs < 216e5 ? `${date}, ${time}` : date;
}

/** "Nice" tick values between min and max. */
export function niceTicks(min: number, max: number, count = 5) {
  const raw = (max - min || 1) / (count - 1);
  const mag = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= raw) ?? 10 * mag;
  const out: number[] = [];
  for (let v = Math.ceil(min / step) * step; v <= max + 1e-9; v += step) out.push(+v.toFixed(10));
  return out;
}

export function humanSpan(ms: number) {
  const min = ms / 6e4;
  if (min < 90) return `${Math.round(min)}m`;
  if (min < 2160) return `${Math.round(min / 60)}h`;
  const d = ms / DAY;
  if (d < 60) return `${Math.round(d)}d`;
  if (d < 800) return `${Math.round(d / 30)}mo`;
  return `${(d / 365).toFixed(1)}y`;
}

export const tone = (v?: number) => (v === undefined ? undefined : v >= 0 ? ("up" as const) : ("down" as const));

export const chartColor = (i: number) => `var(--chart-${(i % 8) + 1})`;
