import type { ChartSeries } from "./chart/InteractiveChart";

/**
 * Demo data generators. Both are seeded, so the same range always gives the
 * same series. Swap these for real data: the chart only needs
 * `{ id, name, data: [{ date, value, volume? }] }[]`, index-aligned,
 * with series[0] as the primary series.
 */

function mulberry(seed: number) {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6d2b79f5) >>> 0;
    let r = t;
    r = Math.imul(r ^ (r >>> 15), r | 1);
    r ^= r + Math.imul(r ^ (r >>> 7), r | 61);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}
const gauss = (rnd: () => number) => Math.sqrt(-2 * Math.log(rnd() || 1e-9)) * Math.cos(2 * Math.PI * rnd());

type RangeCfg = { n: number; step: number; vol: number; drift: number };

export const RANGE_CFG: Record<string, RangeCfg> = {
  "1D": { n: 78, step: 3e5, vol: 0.0018, drift: 4e-5 },
  "5D": { n: 65, step: 72e5, vol: 0.0046, drift: 3e-4 },
  "1M": { n: 22, step: 864e5, vol: 0.012, drift: 0.0028 },
  "6M": { n: 126, step: 864e5, vol: 0.016, drift: 9e-4 },
  "1Y": { n: 252, step: 864e5, vol: 0.018, drift: 0.0011 },
  "5Y": { n: 260, step: 6048e5, vol: 0.045, drift: 0.0075 },
  All: { n: 240, step: 2592e6, vol: 0.11, drift: 0.02 },
};

type SeriesDef = { id: string; name: string; last: number; rho: number; vol: number };

function generate(
  range: string,
  defs: SeriesDef[],
  end: Date,
  opts: { driftScale?: number; volScale?: number; meanRevert?: number; volume: (rnd: () => number, k: number, move: number, stepMs: number) => number },
): ChartSeries[] {
  const cfg = RANGE_CFG[range] ?? RANGE_CFG["1M"];
  const seed = [...range].reduce((a, c) => a * 31 + c.charCodeAt(0), 7);
  const common = mulberry(seed);
  const shocks = Array.from({ length: cfg.n }, () => gauss(common));
  const drift = cfg.drift * (opts.driftScale ?? 1);
  const vol = cfg.vol * (opts.volScale ?? 1);

  return defs.map((def, k) => {
    const rnd = mulberry(seed + k * 101);
    const raw = [100];
    for (let i = 1; i < cfg.n; i++) {
      const z = def.rho * shocks[i] + Math.sqrt(1 - def.rho * def.rho) * gauss(rnd);
      const prev = raw[i - 1];
      raw.push(
        opts.meanRevert
          ? prev + opts.meanRevert * (100 - prev) + 100 * vol * def.vol * z
          : prev * (1 + drift * (k === 0 ? 1 : 0.6) + vol * def.vol * z),
      );
    }
    const scale = def.last / raw[cfg.n - 1];
    const data = raw.map((v, i) => {
      const prev = raw[Math.max(0, i - 1)];
      const move = Math.abs(v / prev - 1);
      return {
        date: new Date(+end - (cfg.n - 1 - i) * cfg.step),
        value: +(v * scale).toFixed(2),
        volume: opts.volume(rnd, k, move, cfg.step),
      };
    });
    return { id: def.id, name: def.name, data };
  });
}

/* ---------- Dataset 1: the Storybook demo (equity) ---------- */
const STOCKS: SeriesDef[] = [
  { id: "nvda", name: "NVDA", last: 207.83, rho: 1, vol: 1 },
  { id: "amd", name: "AMD", last: 164.2, rho: 0.62, vol: 1.05 },
  { id: "spy", name: "S&P 500", last: 548.9, rho: 0.45, vol: 0.45 },
  { id: "qqq", name: "Nasdaq 100", last: 472.1, rho: 0.58, vol: 0.62 },
];

export function stockSeries(range: string) {
  return generate(range, STOCKS, new Date(2026, 4, 7, 16, 0), {
    volume: (rnd, k, move) => Math.round((24e5 + rnd() * 32e5) * (1 + Math.min(2.5, move * 60)) * (k === 0 ? 1 : 0.8)),
  });
}

/* ---------- Dataset 2: maritime fuel consumption (FCPS-style demo) ---------- */
const FUEL: SeriesDef[] = [
  { id: "actual", name: "Actual (ME)", last: 42.6, rho: 1, vol: 1 },
  { id: "predicted", name: "FCPS prediction", last: 41.9, rho: 0.93, vol: 0.55 },
  { id: "sister", name: "Sister vessel", last: 44.1, rho: 0.5, vol: 0.9 },
  { id: "fleet", name: "Fleet baseline", last: 40.2, rho: 0.3, vol: 0.3 },
];

export function fuelSeries(range: string) {
  return generate(range, FUEL, new Date(2026, 10, 20, 12, 0), {
    // Fuel burn hovers around a level instead of trending like a price
    meanRevert: 0.2,
    volScale: 0.9,
    // Distance sailed per bar (nautical miles), ~330–430 nm/day at sea
    volume: (rnd, k, _move, stepMs) => Math.round((330 + rnd() * 100) * (stepMs / 864e5) * (k === 0 ? 1 : 0.95) * 10) / 10,
  });
}

export const fuelFormat = (v: number) => `${v.toLocaleString("en-US", { minimumFractionDigits: 1, maximumFractionDigits: 1 })} t`;
export const nmFormat = (v: number) =>
  `${Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(v)} nm`;
